import React, { useState } from 'react';
import { AppView } from './types';
import ReadingModule from './components/ReadingModule';
import ListeningModule from './components/ListeningModule';
import WritingModule from './components/WritingModule';
import SpeakingModule from './components/SpeakingModule';
import { BookOpen, Headphones, Pencil, Mic } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.READING);

  const renderView = () => {
    switch (view) {
      case AppView.READING:
        return <ReadingModule />;
      case AppView.LISTENING:
        return <ListeningModule />;
      case AppView.WRITING:
        return <WritingModule />;
      case AppView.SPEAKING:
        return <SpeakingModule />;
      default:
        return <ReadingModule />;
    }
  };

  return (
    <div className="h-screen w-full flex flex-col bg-slate-50 relative max-w-md mx-auto shadow-2xl overflow-hidden">
      {/* Header */}
      <header className="bg-white p-4 shadow-sm z-10 flex justify-between items-center border-b border-slate-100">
        <div>
          <h1 className="text-xl font-black text-slate-800">
            IELTS <span className="text-blue-600">Junior</span>
          </h1>
          <p className="text-xs text-slate-500 font-medium">Grade 5 to Band 6 Journey</p>
        </div>
        <div className="bg-yellow-100 text-yellow-800 text-xs font-bold px-2 py-1 rounded">
          Level: Beginner
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden relative">
        {renderView()}
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-slate-200 px-2 py-3 flex justify-around items-center z-20">
        <button
          onClick={() => setView(AppView.LISTENING)}
          className={`flex flex-col items-center gap-1 transition-colors ${
            view === AppView.LISTENING ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <div className={`p-2 rounded-xl ${view === AppView.LISTENING ? 'bg-indigo-50' : 'bg-transparent'}`}>
            <Headphones size={24} strokeWidth={2.5} />
          </div>
          <span className="text-[10px] font-bold">Listening</span>
        </button>

        <button
          onClick={() => setView(AppView.READING)}
          className={`flex flex-col items-center gap-1 transition-colors ${
            view === AppView.READING ? 'text-blue-600' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <div className={`p-2 rounded-xl ${view === AppView.READING ? 'bg-blue-50' : 'bg-transparent'}`}>
            <BookOpen size={24} strokeWidth={2.5} />
          </div>
          <span className="text-[10px] font-bold">Reading</span>
        </button>

        <button
          onClick={() => setView(AppView.WRITING)}
          className={`flex flex-col items-center gap-1 transition-colors ${
            view === AppView.WRITING ? 'text-emerald-600' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <div className={`p-2 rounded-xl ${view === AppView.WRITING ? 'bg-emerald-50' : 'bg-transparent'}`}>
             <Pencil size={24} strokeWidth={2.5} />
          </div>
          <span className="text-[10px] font-bold">Writing</span>
        </button>

        <button
          onClick={() => setView(AppView.SPEAKING)}
          className={`flex flex-col items-center gap-1 transition-colors ${
            view === AppView.SPEAKING ? 'text-rose-600' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <div className={`p-2 rounded-xl ${view === AppView.SPEAKING ? 'bg-rose-50' : 'bg-transparent'}`}>
            <Mic size={24} strokeWidth={2.5} />
          </div>
          <span className="text-[10px] font-bold">Speaking</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
