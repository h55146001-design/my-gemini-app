import React, { useState } from 'react';
import { generateListeningExercise, speakText } from '../services/geminiService';
import { ListeningExercise } from '../types';
import { Headphones, Loader2, PlayCircle, HelpCircle } from 'lucide-react';

const TOPICS = ["School Trip", "Shopping", "Directions", "Hobbies"];

const ListeningModule: React.FC = () => {
  const [exercise, setExercise] = useState<ListeningExercise | null>(null);
  const [loading, setLoading] = useState(false);
  const [answers, setAnswers] = useState<{[key: number]: string}>({});
  const [showResults, setShowResults] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const loadExercise = async (topic: string) => {
    setLoading(true);
    setExercise(null);
    setAnswers({});
    setShowResults(false);
    try {
      const data = await generateListeningExercise(topic);
      setExercise(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const playAudio = () => {
    if (exercise) {
      setIsPlaying(true);
      speakText(exercise.script).then(() => {
          setTimeout(() => setIsPlaying(false), 2000); // Simple timeout reset for UI
      });
    }
  };

  const handleAnswer = (qIndex: number, option: string) => {
    if (showResults) return;
    setAnswers(prev => ({ ...prev, [qIndex]: option }));
  };

  if (!exercise && !loading) {
    return (
      <div className="flex flex-col h-full p-6 bg-indigo-50 overflow-y-auto">
        <h2 className="text-2xl font-bold text-indigo-900 mb-2 flex items-center gap-2">
          <Headphones className="text-indigo-600" /> IELTS Listening
        </h2>
        <p className="text-slate-600 mb-6">Listen to the audio and answer questions.</p>
        <div className="grid grid-cols-2 gap-4">
          {TOPICS.map(t => (
            <button key={t} onClick={() => loadExercise(t)} className="bg-white p-4 rounded-xl shadow-sm border border-indigo-100 hover:border-indigo-400 font-semibold text-slate-700">
              {t}
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center bg-indigo-50">
        <Loader2 className="animate-spin text-indigo-600" size={48} />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white overflow-y-auto">
      {exercise && (
        <>
          <div className="p-8 bg-indigo-50 border-b border-indigo-100 flex flex-col items-center justify-center min-h-[200px]">
            <button onClick={() => setExercise(null)} className="absolute top-4 left-4 text-sm font-bold text-indigo-500 hover:underline">← Exit</button>
            
            <button 
              onClick={playAudio}
              className="bg-indigo-600 text-white rounded-full p-6 shadow-xl hover:bg-indigo-700 active:scale-95 transition-all mb-4"
            >
              <PlayCircle size={48} />
            </button>
            <p className="text-indigo-800 font-medium">
                {isPlaying ? "Listening..." : "Tap to Play Audio"}
            </p>
            <p className="text-xs text-indigo-400 mt-2 uppercase font-bold tracking-widest">Do not read, just listen</p>
          </div>

          <div className="p-6 pb-24 space-y-8">
            {exercise.questions.map((q, idx) => (
              <div key={idx} className="space-y-3">
                <p className="font-bold text-slate-800 text-lg">{idx + 1}. {q.question}</p>
                <div className="space-y-2">
                  {q.options.map((opt) => {
                     const isSelected = answers[idx] === opt;
                     const isCorrect = opt === q.correctAnswer;
                     let btnClass = "bg-white border-slate-200 hover:bg-slate-50";
                     
                     if (showResults) {
                       if (isCorrect) btnClass = "bg-green-100 border-green-500 text-green-800 font-bold";
                       else if (isSelected && !isCorrect) btnClass = "bg-red-50 border-red-300 text-red-800";
                     } else if (isSelected) {
                       btnClass = "bg-indigo-100 border-indigo-500 text-indigo-900 font-medium";
                     }

                     return (
                       <button
                         key={opt}
                         onClick={() => handleAnswer(idx, opt)}
                         className={`w-full text-left p-4 rounded-xl border transition-all ${btnClass}`}
                       >
                         {opt}
                       </button>
                     );
                  })}
                </div>
              </div>
            ))}

            {!showResults ? (
              <button 
                onClick={() => setShowResults(true)}
                disabled={Object.keys(answers).length < exercise.questions.length}
                className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold shadow-lg disabled:opacity-50"
              >
                Submit Answers
              </button>
            ) : (
                <div className="mt-4 p-4 bg-slate-100 rounded-xl">
                    <p className="text-xs font-bold text-slate-500 mb-2 uppercase">Transcript</p>
                    <p className="text-sm text-slate-600 italic">{exercise.script}</p>
                </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default ListeningModule;
