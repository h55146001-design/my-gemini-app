import React, { useRef, useState, useCallback } from 'react';
import Webcam from 'react-webcam';
import { identifyObjectInImage, speakText } from '../services/geminiService';
import { CameraResult } from '../types';
import { Camera, Volume2, RotateCcw, Sparkles } from 'lucide-react';

const MagicCamera: React.FC = () => {
  const webcamRef = useRef<Webcam>(null);
  const [imgSrc, setImgSrc] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<CameraResult | null>(null);

  const capture = useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      setImgSrc(imageSrc);
      if (imageSrc) {
        analyzeImage(imageSrc);
      }
    }
  }, [webcamRef]);

  const analyzeImage = async (base64: string) => {
    setAnalyzing(true);
    const data = await identifyObjectInImage(base64);
    setResult(data);
    setAnalyzing(false);
    if (data?.objectName) {
      speakText(`This is a ${data.objectName}!`);
    }
  };

  const reset = () => {
    setImgSrc(null);
    setResult(null);
  };

  const videoConstraints = {
    facingMode: "environment"
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 overflow-hidden relative">
      {!imgSrc ? (
        <>
          <Webcam
            audio={false}
            ref={webcamRef}
            screenshotFormat="image/jpeg"
            videoConstraints={videoConstraints}
            className="h-full w-full object-cover"
          />
          <div className="absolute bottom-24 w-full flex justify-center pb-8">
            <button
              onClick={capture}
              className="bg-white rounded-full p-1 border-4 border-slate-300 shadow-xl active:scale-95 transition-transform"
            >
              <div className="bg-red-500 rounded-full w-16 h-16 border-4 border-white"></div>
            </button>
          </div>
          <div className="absolute top-4 w-full text-center">
             <span className="bg-black/50 text-white px-4 py-2 rounded-full backdrop-blur-md font-medium">
               Point at something! 📸
             </span>
          </div>
        </>
      ) : (
        <div className="relative h-full flex flex-col">
          <img src={imgSrc} alt="Captured" className="h-1/2 w-full object-cover" />
          
          <div className="flex-1 bg-white -mt-6 rounded-t-3xl relative p-6 flex flex-col items-center">
            {analyzing ? (
               <div className="flex flex-col items-center justify-center h-full">
                 <Sparkles className="text-yellow-400 animate-spin mb-4" size={48} />
                 <p className="text-xl font-bold text-slate-600 animate-pulse">Magic AI is thinking...</p>
               </div>
            ) : result ? (
              <div className="flex flex-col items-center w-full h-full">
                <div className="bg-green-100 w-24 h-24 rounded-full flex items-center justify-center text-6xl shadow-inner mb-4">
                  {result.emoji}
                </div>
                <h2 className="text-4xl font-black text-slate-800 mb-2">{result.objectName}</h2>
                <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200 mb-6 w-full text-center">
                   <p className="text-yellow-800 text-lg">{result.funFact}</p>
                </div>
                
                <div className="flex gap-4">
                  <button 
                    onClick={() => speakText(result.objectName)}
                    className="flex items-center gap-2 bg-blue-500 text-white px-6 py-3 rounded-full font-bold shadow-lg hover:bg-blue-600 active:translate-y-1 transition-all"
                  >
                    <Volume2 size={24} /> Hear It
                  </button>
                  <button 
                    onClick={reset}
                    className="flex items-center gap-2 bg-slate-200 text-slate-700 px-6 py-3 rounded-full font-bold shadow-lg hover:bg-slate-300 active:translate-y-1 transition-all"
                  >
                    <RotateCcw size={24} /> Again
                  </button>
                </div>
              </div>
            ) : (
               <div className="text-red-500">Could not identify. Try again!</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default MagicCamera;
