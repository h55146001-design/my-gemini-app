import React, { useState } from 'react';
import { generateQuiz, speakText } from '../services/geminiService';
import { QuizQuestion } from '../types';
import { Brain, CheckCircle, XCircle, Trophy, RefreshCw, Loader2 } from 'lucide-react';

const TOPICS = ["Science", "History", "Literature", "Logic", "Environment", "Technology"];

const QuizTime: React.FC = () => {
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [quizComplete, setQuizComplete] = useState(false);

  const handleTopicSelect = async (topic: string) => {
    setSelectedTopic(topic);
    setLoading(true);
    setScore(0);
    setCurrentQuestionIndex(0);
    setQuizComplete(false);
    try {
      const quizData = await generateQuiz(topic);
      setQuestions(quizData);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (option: string) => {
    if (answered) return;

    setAnswered(true);
    setSelectedAnswer(option);
    
    const currentQuestion = questions[currentQuestionIndex];
    const isCorrect = option === currentQuestion.correctAnswer;

    if (isCorrect) {
      setScore(s => s + 1);
      speakText("Correct.");
    } else {
      speakText(`Incorrect. The answer is ${currentQuestion.correctAnswer}`);
    }

    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
        setAnswered(false);
        setSelectedAnswer(null);
      } else {
        setQuizComplete(true);
        speakText(`Quiz complete. You scored ${score + (isCorrect ? 1 : 0)} out of ${questions.length}`);
      }
    }, 2500);
  };

  const resetQuiz = () => {
    setSelectedTopic(null);
    setQuestions([]);
    setQuizComplete(false);
  };

  if (!selectedTopic) {
    return (
      <div className="flex flex-col h-full overflow-y-auto p-6 pb-24 bg-orange-50">
        <h2 className="text-3xl font-black text-center text-orange-800 mb-2 flex items-center justify-center gap-2">
          <Brain size={32} /> Knowledge Quiz
        </h2>
        <p className="text-center text-slate-500 mb-8 font-medium">Challenge your mind</p>
        
        <div className="grid grid-cols-2 gap-4">
          {TOPICS.map((topic) => (
            <button
              key={topic}
              onClick={() => handleTopicSelect(topic)}
              className="aspect-square flex flex-col items-center justify-center bg-white rounded-2xl shadow-md border-b-4 border-orange-200 active:border-b-0 active:translate-y-1 transition-all hover:bg-orange-100"
            >
              <span className="text-4xl mb-3">
                {topic === "Science" ? "🧬" : 
                 topic === "History" ? "📜" : 
                 topic === "Literature" ? "📚" : 
                 topic === "Logic" ? "♟️" :
                 topic === "Environment" ? "🌱" : "💻"}
              </span>
              <span className="font-bold text-slate-700">{topic}</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-orange-600 h-full p-4">
        <Loader2 size={48} className="animate-spin mb-4" />
        <p className="text-xl font-medium animate-pulse text-center">Preparing questions...</p>
      </div>
    );
  }

  if (quizComplete) {
    return (
      <div className="flex flex-col h-full items-center justify-center p-6 bg-orange-50">
        <Trophy size={80} className="text-yellow-500 mb-6 drop-shadow-md animate-bounce" />
        <h2 className="text-4xl font-black text-slate-800 mb-2">Quiz Results</h2>
        <p className="text-2xl text-orange-700 font-bold mb-8">
          Score: {score} / {questions.length}
        </p>
        <button
          onClick={resetQuiz}
          className="bg-orange-600 text-white text-lg font-bold py-3 px-8 rounded-full shadow-lg active:scale-95 transition-transform flex items-center gap-2"
        >
          <RefreshCw /> Try Another Topic
        </button>
      </div>
    );
  }

  const currentQ = questions[currentQuestionIndex];

  return (
    <div className="flex flex-col h-full p-4 pb-24 bg-orange-50">
      <div className="flex justify-between items-center mb-6">
         <button onClick={resetQuiz} className="text-orange-700 font-bold hover:underline">Exit</button>
         <div className="bg-white px-4 py-1 rounded-full text-orange-700 font-bold shadow-sm border border-orange-200">
           Question {currentQuestionIndex + 1} / {questions.length}
         </div>
      </div>

      <div className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-6 border border-orange-200 min-h-[160px] flex items-center justify-center text-center">
          <h3 className="text-xl font-semibold text-slate-800 leading-snug">
            {currentQ.question}
          </h3>
        </div>

        <div className="space-y-3">
          {currentQ.options.map((option, idx) => {
            const isSelected = selectedAnswer === option;
            const isCorrect = option === currentQ.correctAnswer;
            
            let btnClass = "bg-white border border-slate-200 text-slate-700";
            if (answered) {
              if (isCorrect) btnClass = "bg-green-100 border-green-400 text-green-900 font-bold";
              else if (isSelected && !isCorrect) btnClass = "bg-red-100 border-red-400 text-red-900";
              else btnClass = "bg-slate-50 opacity-50";
            } else {
              btnClass = "bg-white border-b-4 border-slate-200 text-slate-700 hover:bg-orange-50 active:border-b-0 active:translate-y-1";
            }

            return (
              <button
                key={idx}
                onClick={() => handleAnswer(option)}
                disabled={answered}
                className={`w-full py-4 px-4 rounded-xl text-lg font-medium transition-all shadow-sm flex items-center justify-center relative ${btnClass}`}
              >
                {option}
                {answered && isCorrect && <CheckCircle className="absolute right-4 text-green-600" size={20} />}
                {answered && isSelected && !isCorrect && <XCircle className="absolute right-4 text-red-600" size={20} />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default QuizTime;