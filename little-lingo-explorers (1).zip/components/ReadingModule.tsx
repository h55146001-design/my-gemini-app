import React, { useState } from 'react';
import { generateReadingMaterial } from '../services/geminiService';
import { ReadingMaterial } from '../types';
import { BookOpen, Loader2, CheckCircle, XCircle } from 'lucide-react';

const TOPICS = ["Animals", "Space", "Inventions", "Nature", "Sports"];

const ReadingModule: React.FC = () => {
  const [material, setMaterial] = useState<ReadingMaterial | null>(null);
  const [loading, setLoading] = useState(false);
  const [answers, setAnswers] = useState<{[key: number]: string}>({});
  const [showResults, setShowResults] = useState(false);

  const loadMaterial = async (topic: string) => {
    setLoading(true);
    setMaterial(null);
    setAnswers({});
    setShowResults(false);
    try {
      const data = await generateReadingMaterial(topic);
      setMaterial(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (qIndex: number, option: string) => {
    if (showResults) return;
    setAnswers(prev => ({ ...prev, [qIndex]: option }));
  };

  if (!material && !loading) {
    return (
      <div className="flex flex-col h-full p-6 bg-blue-50 overflow-y-auto">
        <h2 className="text-2xl font-bold text-blue-900 mb-2 flex items-center gap-2">
          <BookOpen className="text-blue-600" /> IELTS Reading
        </h2>
        <p className="text-slate-600 mb-6">Select a topic to practice reading comprehension.</p>
        <div className="grid grid-cols-2 gap-4">
          {TOPICS.map(t => (
            <button key={t} onClick={() => loadMaterial(t)} className="bg-white p-4 rounded-xl shadow-sm border border-blue-100 hover:border-blue-400 font-semibold text-slate-700">
              {t}
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center bg-blue-50">
        <Loader2 className="animate-spin text-blue-600" size={48} />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white overflow-y-auto">
      {material && (
        <>
          <div className="p-6 bg-blue-50 border-b border-blue-100">
            <button onClick={() => setMaterial(null)} className="text-sm font-bold text-blue-500 mb-2 hover:underline">← Back to Topics</button>
            <h2 className="text-xl font-bold text-slate-800 mb-2">{material.title}</h2>
            <div className="bg-white p-4 rounded-xl shadow-sm text-slate-700 leading-relaxed text-lg font-serif">
              {material.passage}
            </div>
            
            {/* Vocab Section */}
            <div className="mt-4 flex gap-2 overflow-x-auto pb-2 no-scrollbar">
              {material.vocabulary.map((v, i) => (
                <div key={i} className="flex-shrink-0 bg-yellow-50 border border-yellow-200 px-3 py-2 rounded-lg text-sm">
                  <span className="font-bold text-slate-800">{v.word}</span>: <span className="text-slate-600">{v.definition}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="p-6 pb-24 space-y-6">
            <h3 className="font-bold text-slate-400 uppercase text-sm tracking-wider">Comprehension Check</h3>
            {material.questions.map((q, idx) => (
              <div key={idx} className="space-y-2">
                <p className="font-medium text-slate-800">{idx + 1}. {q.question}</p>
                <div className="grid grid-cols-1 gap-2">
                  {q.options.map((opt) => {
                     const isSelected = answers[idx] === opt;
                     const isCorrect = opt === q.correctAnswer;
                     let btnClass = "border-slate-200 hover:bg-slate-50";
                     
                     if (showResults) {
                       if (isCorrect) btnClass = "bg-green-100 border-green-500 text-green-800";
                       else if (isSelected && !isCorrect) btnClass = "bg-red-50 border-red-300 text-red-800";
                     } else if (isSelected) {
                       btnClass = "bg-blue-100 border-blue-500 text-blue-800";
                     }

                     return (
                       <button
                         key={opt}
                         onClick={() => handleAnswer(idx, opt)}
                         className={`w-full text-left p-3 rounded-lg border text-sm transition-colors ${btnClass}`}
                       >
                         {opt}
                       </button>
                     );
                  })}
                </div>
              </div>
            ))}

            {!showResults ? (
              <button 
                onClick={() => setShowResults(true)}
                disabled={Object.keys(answers).length < material.questions.length}
                className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold shadow-lg disabled:opacity-50"
              >
                Check Answers
              </button>
            ) : (
              <div className="p-4 bg-green-50 rounded-xl text-center text-green-800 font-bold border border-green-200">
                Completed! 
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default ReadingModule;
