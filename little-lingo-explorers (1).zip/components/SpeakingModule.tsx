import React, { useState, useRef } from 'react';
import { generateSpeakingChallenge, evaluateSpeech, speakText } from '../services/geminiService';
import { blobToBase64 } from '../services/audioUtils';
import { SpeakingChallenge, SpeakingResult } from '../types';
import { Mic, Volume2, RefreshCw, Loader2, Sparkles, MessageCircle } from 'lucide-react';

const SpeakingModule: React.FC = () => {
  const [challenge, setChallenge] = useState<SpeakingChallenge | null>(null);
  const [loading, setLoading] = useState(false);
  const [evaluating, setEvaluating] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [result, setResult] = useState<SpeakingResult | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const getChallenge = async () => {
    setLoading(true);
    setResult(null);
    try {
      const data = await generateSpeakingChallenge();
      setChallenge(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        await processAudio(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Microphone access denied:", err);
      alert("Please allow microphone access.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const processAudio = async (blob: Blob) => {
    if (!challenge) return;
    setEvaluating(true);
    try {
      const base64Audio = await blobToBase64(blob);
      const evalResult = await evaluateSpeech(base64Audio, challenge.question);
      setResult(evalResult);
    } catch (e) {
      console.error(e);
    } finally {
      setEvaluating(false);
    }
  };

  if (!challenge && !loading) {
    return (
      <div className="flex flex-col h-full items-center justify-center p-6 bg-rose-50 text-center">
         <div className="bg-white p-6 rounded-full shadow-md mb-6">
           <Mic size={48} className="text-rose-500" />
         </div>
         <h2 className="text-2xl font-bold text-rose-900 mb-2">IELTS Speaking</h2>
         <p className="text-slate-600 mb-8 max-w-xs">Simulate the interview. Answer questions and get feedback on fluency.</p>
         <button 
           onClick={getChallenge}
           className="bg-rose-600 text-white text-lg font-bold py-3 px-8 rounded-full shadow-lg hover:bg-rose-700 transition-transform active:scale-95"
         >
           Start Interview
         </button>
      </div>
    );
  }

  if (loading) {
     return (
        <div className="flex h-full items-center justify-center bg-rose-50">
           <Loader2 size={48} className="animate-spin text-rose-600" />
        </div>
     );
  }

  return (
    <div className="flex flex-col h-full p-6 pb-24 bg-rose-50 overflow-y-auto">
      <div className="flex justify-between items-center mb-6">
        <span className="bg-rose-100 text-rose-800 text-xs font-bold px-2 py-1 rounded uppercase">Part 1: Interview</span>
        <button onClick={getChallenge} className="text-slate-400 hover:text-rose-500">
            <RefreshCw size={20} />
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center">
        {challenge && (
            <div className="bg-white p-8 rounded-3xl shadow-xl w-full mb-8 border border-rose-100 relative">
                <MessageCircle className="absolute top-4 right-4 text-rose-200" size={40} />
                <p className="text-sm text-slate-400 font-bold uppercase mb-2">Examiner asks:</p>
                <h3 className="text-2xl font-serif text-slate-800 font-medium leading-relaxed mb-4">
                    "{challenge.question}"
                </h3>
                <div className="bg-rose-50 p-3 rounded-lg text-rose-800 text-sm">
                   <strong>Tip:</strong> {challenge.tips}
                </div>
                <button 
                  onClick={() => speakText(challenge.question)}
                  className="mt-4 flex items-center gap-2 text-rose-600 font-bold text-sm hover:underline"
                >
                    <Volume2 size={18} /> Hear Question
                </button>
            </div>
        )}

        <div className="w-full flex justify-center mb-8">
            <button
                onMouseDown={startRecording}
                onMouseUp={stopRecording}
                onTouchStart={startRecording}
                onTouchEnd={stopRecording}
                disabled={evaluating}
                className={`w-24 h-24 rounded-full flex items-center justify-center shadow-2xl transition-all transform ${
                    isRecording 
                    ? 'bg-rose-600 scale-110 ring-4 ring-rose-300' 
                    : evaluating 
                        ? 'bg-slate-300' 
                        : 'bg-rose-500 hover:bg-rose-600 active:scale-95'
                }`}
            >
                {evaluating ? (
                    <Loader2 size={40} className="text-white animate-spin" />
                ) : (
                    <Mic size={40} className="text-white" />
                )}
            </button>
        </div>
        <p className="text-rose-800/60 text-sm font-medium mb-6 animate-pulse">
            {isRecording ? "Recording... Release to finish" : evaluating ? "Examiner is thinking..." : "Hold to Answer"}
        </p>

        {result && (
            <div className="w-full bg-white rounded-2xl shadow-xl p-6 border-t-4 border-rose-500 animate-fade-in">
                <div className="flex justify-between items-center mb-4">
                    <h4 className="font-bold text-slate-700 text-lg">Evaluation</h4>
                    <div className="bg-rose-100 text-rose-800 px-3 py-1 rounded-lg font-bold">
                        Band {result.score}
                    </div>
                </div>
                <div className="space-y-3">
                    <div>
                        <p className="text-xs text-slate-400 font-bold uppercase">You said:</p>
                        <p className="text-slate-600 italic">"{result.transcribedText}"</p>
                    </div>
                    <div className="bg-rose-50 p-3 rounded-lg">
                        <p className="text-rose-900 text-sm leading-relaxed">
                            <Sparkles size={14} className="inline mr-1 text-rose-500" />
                            {result.feedback}
                        </p>
                    </div>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default SpeakingModule;
