import React, { useState, useRef } from 'react';
import { generatePronunciationChallenge, evaluateSpeech, speakText } from '../services/geminiService';
import { blobToBase64 } from '../services/audioUtils';
import { PronunciationChallenge, SpeakingResult } from '../types';
import { Mic, Volume2, RefreshCw, Loader2, Sparkles, AlertCircle } from 'lucide-react';

const TOPICS = ["Debate", "Daily Routine", "Travel", "Opinions", "Future", "School Life"];

const SpeakingPractice: React.FC = () => {
  const [topic, setTopic] = useState<string | null>(null);
  const [challenge, setChallenge] = useState<PronunciationChallenge | null>(null);
  const [loading, setLoading] = useState(false);
  const [evaluating, setEvaluating] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [result, setResult] = useState<SpeakingResult | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const handleTopicSelect = async (t: string) => {
    setTopic(t);
    setLoading(true);
    setResult(null);
    try {
      const data = await generatePronunciationChallenge(t);
      setChallenge(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        await processAudio(blob);
        stream.getTracks().forEach(track => track.stop()); // Stop mic
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Microphone access denied:", err);
      alert("Please allow microphone access to use this feature.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const processAudio = async (blob: Blob) => {
    if (!challenge) return;
    setEvaluating(true);
    try {
      const base64Audio = await blobToBase64(blob);
      const evalResult = await evaluateSpeech(base64Audio, challenge.phrase);
      setResult(evalResult);
      if (evalResult.score > 80) {
        speakText("Excellent pronunciation!");
      } else {
        speakText("Good try. Listen to the feedback.");
      }
    } catch (e) {
      console.error(e);
    } finally {
      setEvaluating(false);
    }
  };

  const nextChallenge = () => {
    if (topic) handleTopicSelect(topic);
  };

  if (!topic) {
    return (
      <div className="flex flex-col h-full overflow-y-auto p-6 pb-24 bg-teal-50">
        <h2 className="text-3xl font-black text-center text-teal-800 mb-2 flex items-center justify-center gap-2">
          <Mic size={32} /> Oral Practice
        </h2>
        <p className="text-center text-slate-500 mb-8 font-medium">Improve your pronunciation</p>
        
        <div className="grid grid-cols-2 gap-4">
          {TOPICS.map((t) => (
            <button
              key={t}
              onClick={() => handleTopicSelect(t)}
              className="aspect-square flex flex-col items-center justify-center bg-white rounded-2xl shadow-md border border-teal-200 hover:shadow-xl hover:bg-teal-100 transition-all active:scale-95"
            >
              <span className="text-2xl font-bold text-teal-700 mb-1">{t}</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (loading) {
    return (
       <div className="flex-1 flex flex-col items-center justify-center text-teal-600">
          <Loader2 size={48} className="animate-spin mb-4" />
          <p className="text-lg font-medium animate-pulse">Creating challenge...</p>
       </div>
    );
  }

  return (
    <div className="flex flex-col h-full p-6 pb-24 bg-teal-50 overflow-y-auto">
      <div className="flex justify-between items-center mb-6">
        <button onClick={() => setTopic(null)} className="text-teal-700 font-bold hover:underline">Back</button>
        <button onClick={nextChallenge} className="flex items-center gap-2 text-teal-700 font-bold bg-white px-3 py-1 rounded-full shadow-sm">
            Next <RefreshCw size={16}/>
        </button>
      </div>

      {challenge && (
        <div className="flex-1 flex flex-col items-center">
            <div className="bg-white p-8 rounded-3xl shadow-lg w-full mb-8 relative border border-teal-100">
                <span className="absolute top-4 right-4 bg-teal-100 text-teal-800 text-xs px-2 py-1 rounded font-bold uppercase tracking-wider">
                    {challenge.difficulty}
                </span>
                <p className="text-sm text-slate-400 font-bold uppercase mb-2">Read this aloud:</p>
                <h3 className="text-2xl font-serif text-slate-800 font-medium leading-relaxed mb-4">
                    "{challenge.phrase}"
                </h3>
                <div className="flex items-center gap-2 text-slate-500 text-sm italic bg-slate-50 p-3 rounded-lg">
                    <AlertCircle size={16} />
                    {challenge.context}
                </div>
                <button 
                  onClick={() => speakText(challenge.phrase)}
                  className="mt-4 flex items-center gap-2 text-teal-600 font-bold text-sm hover:underline"
                >
                    <Volume2 size={18} /> Listen to model
                </button>
            </div>

            <div className="w-full flex justify-center mb-8">
                <button
                    onMouseDown={startRecording}
                    onMouseUp={stopRecording}
                    onTouchStart={startRecording}
                    onTouchEnd={stopRecording}
                    disabled={evaluating}
                    className={`w-24 h-24 rounded-full flex items-center justify-center shadow-2xl transition-all transform ${
                        isRecording 
                        ? 'bg-red-500 scale-110 ring-4 ring-red-200' 
                        : evaluating 
                            ? 'bg-slate-300' 
                            : 'bg-teal-500 hover:bg-teal-600 active:scale-95'
                    }`}
                >
                    {evaluating ? (
                        <Loader2 size={40} className="text-white animate-spin" />
                    ) : (
                        <Mic size={40} className="text-white" />
                    )}
                </button>
            </div>
            <p className="text-slate-500 text-sm font-medium mb-6">
                {isRecording ? "Recording... Release to send" : evaluating ? "Analyzing..." : "Press and hold to record"}
            </p>

            {result && (
                <div className="w-full bg-white rounded-2xl shadow-xl p-6 border-t-4 border-teal-500 animate-fade-in">
                    <div className="flex justify-between items-center mb-4">
                        <h4 className="font-bold text-slate-700 text-lg">Feedback</h4>
                        <div className={`text-2xl font-black ${result.score > 80 ? 'text-green-500' : 'text-orange-500'}`}>
                            {result.score}/100
                        </div>
                    </div>
                    <div className="space-y-3">
                        <div>
                            <p className="text-xs text-slate-400 font-bold uppercase">We heard:</p>
                            <p className={`text-slate-700 ${result.transcribedText.toLowerCase() === challenge.phrase.toLowerCase() ? 'text-green-700' : ''}`}>
                                "{result.transcribedText}"
                            </p>
                        </div>
                        <div className="bg-teal-50 p-3 rounded-lg">
                            <p className="text-teal-800 text-sm leading-relaxed">
                                <Sparkles size={14} className="inline mr-1" />
                                {result.feedback}
                            </p>
                        </div>
                    </div>
                </div>
            )}
        </div>
      )}
    </div>
  );
};

export default SpeakingPractice;
