import React, { useState } from 'react';
import { generateStory, speakText } from '../services/geminiService';
import { StoryData } from '../types';
import { BookOpen, Play, RefreshCw, Wand2 } from 'lucide-react';

const StoryTime: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [story, setStory] = useState<StoryData | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    try {
      const data = await generateStory(topic);
      setStory(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const playStory = () => {
    if (story) {
      speakText(`${story.title}. ${story.content}`);
    }
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto p-4 pb-24 bg-purple-50">
      <h2 className="text-3xl font-black text-center text-purple-800 mb-6 flex items-center justify-center gap-2">
        <BookOpen size={32} /> Story Studio
      </h2>

      {!story && !loading && (
        <div className="flex flex-col items-center justify-center flex-1">
          <div className="bg-white p-6 rounded-3xl shadow-xl w-full max-w-sm border border-purple-100">
            <label className="block text-slate-600 font-bold mb-2 ml-1">Topic</label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., A time travel adventure..."
              className="w-full text-lg p-4 rounded-xl border-2 border-purple-200 focus:border-purple-500 focus:outline-none bg-purple-50 mb-4"
            />
            <button
              onClick={handleGenerate}
              disabled={!topic.trim()}
              className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xl font-bold py-4 rounded-xl shadow-lg hover:shadow-xl active:scale-95 transition-all disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-2"
            >
              <Wand2 /> Create Story
            </button>
            <div className="mt-6 flex flex-wrap gap-2 justify-center">
              {['Mystery', 'Sci-Fi', 'Fantasy', 'Adventure'].map(t => (
                <button 
                  key={t} 
                  onClick={() => setTopic(t)}
                  className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-semibold hover:bg-purple-200"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {loading && (
         <div className="flex-1 flex flex-col items-center justify-center text-purple-500">
           <div className="animate-bounce text-6xl mb-4">📖</div>
           <p className="text-xl font-medium animate-pulse">Writing an engaging story...</p>
         </div>
      )}

      {story && !loading && (
        <div className="flex-1 flex flex-col">
           <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-purple-200">
             <div className="bg-purple-100 p-6 text-center border-b border-purple-200">
               <div className="text-6xl mb-4">{story.emoji}</div>
               <h3 className="text-2xl font-bold text-purple-900 leading-tight font-serif">{story.title}</h3>
             </div>
             <div className="p-6 md:p-8">
               <p className="text-lg text-slate-700 leading-relaxed font-serif">
                 {story.content}
               </p>
             </div>
           </div>

           <div className="mt-6 flex gap-3 justify-center">
             <button
               onClick={playStory}
               className="flex-1 bg-green-600 text-white py-4 rounded-2xl font-bold text-lg shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-2"
             >
               <Play size={24} fill="currentColor" /> Narrate
             </button>
             <button
               onClick={() => { setStory(null); setTopic(''); }}
               className="bg-white text-purple-600 py-4 px-6 rounded-2xl font-bold text-lg shadow-lg active:scale-95 transition-transform border border-purple-200"
             >
               <RefreshCw size={24} />
             </button>
           </div>
        </div>
      )}
    </div>
  );
};

export default StoryTime;