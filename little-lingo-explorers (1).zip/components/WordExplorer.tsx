import React, { useState } from 'react';
import { generateVocabulary, speakText } from '../services/geminiService';
import { VocabCard } from '../types';
import { Volume2, Loader2, RefreshCw } from 'lucide-react';

// Updated topics for 6th Grade level
const TOPICS = ["Technology", "Environment", "Space", "History", "Science", "Literature", "Geography", "Art"];

const WordExplorer: React.FC = () => {
  const [cards, setCards] = useState<VocabCard[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);

  const handleTopicSelect = async (topic: string) => {
    setSelectedTopic(topic);
    setLoading(true);
    try {
      const newCards = await generateVocabulary(topic);
      setCards(newCards);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const playWord = (text: string) => {
    speakText(text);
  };

  if (!selectedTopic) {
    return (
      <div className="flex flex-col h-full overflow-y-auto p-6 pb-24">
        <h2 className="text-3xl font-bold text-center text-blue-800 mb-2">Word Lab</h2>
        <p className="text-center text-slate-500 mb-8 font-medium">Expand your vocabulary (Grade 6)</p>
        
        <div className="grid grid-cols-2 gap-4">
          {TOPICS.map((topic) => (
            <button
              key={topic}
              onClick={() => handleTopicSelect(topic)}
              className="aspect-square flex flex-col items-center justify-center bg-white rounded-2xl shadow-md border border-slate-200 hover:shadow-xl hover:border-blue-300 transition-all active:scale-95"
            >
              <span className="text-4xl mb-3">
                {topic === "Technology" ? "💻" : 
                 topic === "Environment" ? "🌍" : 
                 topic === "Space" ? "🌌" : 
                 topic === "History" ? "🏛️" :
                 topic === "Science" ? "🧬" :
                 topic === "Literature" ? "📚" :
                 topic === "Geography" ? "🗺️" : "🎨"}
              </span>
              <span className="font-bold text-slate-700">{topic}</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full overflow-y-auto p-4 pb-24 bg-slate-50">
      <div className="flex justify-between items-center mb-6">
        <button 
          onClick={() => { setSelectedTopic(null); setCards([]); }}
          className="bg-white px-4 py-2 rounded-lg shadow-sm text-slate-600 font-bold hover:bg-slate-100 border border-slate-200"
        >
          ← Topics
        </button>
        <div className="bg-blue-600 px-4 py-2 rounded-lg text-white font-bold shadow-md">
          {selectedTopic}
        </div>
        <button 
           onClick={() => handleTopicSelect(selectedTopic)}
           disabled={loading}
           className="p-2 bg-white rounded-lg text-blue-600 shadow-sm border border-slate-200 hover:bg-blue-50"
        >
          <RefreshCw size={20} className={loading ? "animate-spin" : ""} />
        </button>
      </div>

      {loading ? (
        <div className="flex-1 flex flex-col items-center justify-center text-blue-500">
          <Loader2 size={48} className="animate-spin mb-4" />
          <p className="text-lg font-medium animate-pulse">Generating advanced vocabulary...</p>
        </div>
      ) : (
        <div className="space-y-6">
          {cards.map((card, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden border border-slate-200">
              <div className="bg-gradient-to-r from-slate-700 to-slate-800 p-5 flex items-center justify-between text-white">
                 <div className="flex items-center gap-4">
                     <span className="text-4xl">{card.emoji}</span>
                     <h3 className="text-2xl font-bold tracking-wide">{card.word}</h3>
                 </div>
                 <button 
                  onClick={() => playWord(card.word)}
                  className="bg-white/20 hover:bg-white/30 p-2 rounded-full backdrop-blur-sm transition-colors"
                 >
                   <Volume2 size={24} className="text-white" />
                 </button>
              </div>
              <div className="p-6">
                <p className="text-slate-600 font-medium text-lg mb-4 leading-relaxed">{card.definition}</p>
                <div className="bg-blue-50 p-4 rounded-xl border-l-4 border-blue-400">
                  <p className="text-slate-700 italic">"{card.sentence}"</p>
                  <button onClick={() => playWord(card.sentence)} className="mt-3 flex items-center text-blue-600 text-xs font-bold uppercase tracking-wide hover:underline">
                    <Volume2 size={14} className="mr-1" /> Listen
                  </button>
                </div>
              </div>
            </div>
          ))}
          <div className="h-8"></div>
        </div>
      )}
    </div>
  );
};

export default WordExplorer;