import React, { useState } from 'react';
import { generateWritingPrompt, evaluateWriting } from '../services/geminiService';
import { WritingPrompt, WritingFeedback } from '../types';
import { Pencil, Send, Loader2, Sparkles, RefreshCcw } from 'lucide-react';

const WritingModule: React.FC = () => {
  const [prompt, setPrompt] = useState<WritingPrompt | null>(null);
  const [userText, setUserText] = useState("");
  const [feedback, setFeedback] = useState<WritingFeedback | null>(null);
  const [loading, setLoading] = useState(false);
  const [evaluating, setEvaluating] = useState(false);

  const getNewPrompt = async () => {
    setLoading(true);
    setPrompt(null);
    setFeedback(null);
    setUserText("");
    try {
      const data = await generateWritingPrompt();
      setPrompt(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!prompt || !userText.trim()) return;
    setEvaluating(true);
    try {
      const result = await evaluateWriting(prompt.question, userText);
      setFeedback(result);
    } catch (e) {
      console.error(e);
    } finally {
      setEvaluating(false);
    }
  };

  if (!prompt && !loading) {
    return (
      <div className="flex flex-col h-full items-center justify-center p-6 bg-emerald-50 text-center">
        <div className="bg-white p-6 rounded-full shadow-md mb-6">
          <Pencil size={48} className="text-emerald-500" />
        </div>
        <h2 className="text-2xl font-bold text-emerald-900 mb-2">IELTS Writing</h2>
        <p className="text-slate-600 mb-8 max-w-xs">Practice short essays and letters. Get instant AI grading.</p>
        <button 
          onClick={getNewPrompt}
          className="bg-emerald-600 text-white text-lg font-bold py-3 px-8 rounded-full shadow-lg hover:bg-emerald-700 transition-transform active:scale-95"
        >
          Start Writing
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center bg-emerald-50">
        <Loader2 className="animate-spin text-emerald-600" size={48} />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-emerald-50 overflow-y-auto pb-24">
      {/* Prompt Section */}
      <div className="bg-white p-6 shadow-sm border-b border-emerald-100">
        <div className="flex justify-between items-start mb-2">
            <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2 py-1 rounded uppercase">Task 1</span>
            <button onClick={getNewPrompt} className="text-slate-400 hover:text-emerald-500"><RefreshCcw size={18} /></button>
        </div>
        <h3 className="text-lg font-bold text-slate-800 mb-2">{prompt?.question}</h3>
        <p className="text-sm text-slate-500">Min words: {prompt?.minWords}</p>
      </div>

      {/* Writing Area */}
      {!feedback ? (
        <div className="p-4 flex-1 flex flex-col">
          <textarea
            className="flex-1 w-full p-4 rounded-xl border border-emerald-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none resize-none text-slate-700 bg-white shadow-inner mb-4"
            placeholder="Type your answer here..."
            value={userText}
            onChange={(e) => setUserText(e.target.value)}
          />
          <button
            onClick={handleSubmit}
            disabled={userText.length < 10 || evaluating}
            className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {evaluating ? <Loader2 className="animate-spin" /> : <><Send size={18} /> Submit for Grading</>}
          </button>
        </div>
      ) : (
        <div className="p-4 space-y-4">
          <div className="bg-white p-6 rounded-2xl shadow-lg border-t-4 border-emerald-500">
             <div className="flex justify-between items-center mb-4">
               <h4 className="font-bold text-slate-700">Band Score</h4>
               <div className="bg-emerald-100 text-emerald-800 text-2xl font-black px-4 py-2 rounded-lg">
                 {feedback.score}
               </div>
             </div>
             <p className="text-slate-600 mb-4">{feedback.comments}</p>
             
             <div className="bg-red-50 p-4 rounded-lg mb-4 border border-red-100">
               <h5 className="text-red-800 font-bold text-sm mb-2 uppercase">Corrections</h5>
               <p className="text-slate-700 text-sm whitespace-pre-wrap">{feedback.corrections}</p>
             </div>

             <div className="bg-green-50 p-4 rounded-lg border border-green-100">
               <h5 className="text-green-800 font-bold text-sm mb-2 uppercase flex items-center gap-2"><Sparkles size={14}/> Better Version</h5>
               <p className="text-slate-700 text-sm italic">{feedback.improvedVersion}</p>
             </div>
          </div>
          <button 
            onClick={getNewPrompt}
            className="w-full bg-white text-emerald-600 border border-emerald-200 py-3 rounded-xl font-bold"
          >
            New Topic
          </button>
        </div>
      )}
    </div>
  );
};

export default WritingModule;
