import { GoogleGenAI, Type, Modality } from "@google/genai";
import { 
  ReadingMaterial, 
  ListeningExercise, 
  WritingPrompt, 
  WritingFeedback, 
  SpeakingChallenge, 
  SpeakingResult,
  VocabCard,
  CameraResult,
  StoryData,
  QuizQuestion,
  PronunciationChallenge
} from "../types";
import { decodeBase64, decodeAudioData, playAudioBuffer } from "./audioUtils";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

let audioContext: AudioContext | null = null;

function getAudioContext() {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({
      sampleRate: 24000,
    });
  }
  return audioContext;
}

// --- READING ---
export const generateReadingMaterial = async (topic: string): Promise<ReadingMaterial> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Create an IELTS-style reading exercise for a 5th-grade student (approx. 10-11 years old). 
    Topic: "${topic}".
    1. Write a passage (approx. 150-200 words) that is interesting and educational.
    2. Define 3 key vocabulary words from the text.
    3. Create 3 multiple-choice comprehension questions.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          passage: { type: Type.STRING },
          vocabulary: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                word: { type: Type.STRING },
                definition: { type: Type.STRING },
              },
            },
          },
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctAnswer: { type: Type.STRING },
              },
            },
          },
        },
      },
    },
  });
  return JSON.parse(response.text || "{}");
};

// --- LISTENING ---
export const generateListeningExercise = async (topic: string): Promise<ListeningExercise> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Create an IELTS-style listening script for a 5th-grade student.
    Topic: "${topic}".
    1. Write a short monologue or dialogue (approx. 100-120 words). It should sound natural.
    2. Create 3 multiple-choice questions based on specific details in the script.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          script: { type: Type.STRING },
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctAnswer: { type: Type.STRING },
              },
            },
          },
        },
      },
    },
  });
  return JSON.parse(response.text || "{}");
};

// --- WRITING ---
export const generateWritingPrompt = async (): Promise<WritingPrompt> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Generate a simple IELTS General Training Task 1 style writing prompt suitable for a 10-year-old student (Grade 5).
    Example topics: Writing an email to a friend, describing a hobby, planning a holiday.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          topic: { type: Type.STRING },
          question: { type: Type.STRING },
          minWords: { type: Type.NUMBER },
        },
      },
    },
  });
  return JSON.parse(response.text || "{}");
};

export const evaluateWriting = async (prompt: string, userText: string): Promise<WritingFeedback> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Evaluate this writing submission from a 5th-grade student preparing for IELTS.
    Prompt: "${prompt}"
    Student Text: "${userText}"
    
    1. Give an estimated IELTS Band Score (scale 0-9, but adjusted for a kid beginner, e.g., 4.0 is good).
    2. Provide constructive feedback.
    3. Show a corrected/improved version.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          comments: { type: Type.STRING },
          corrections: { type: Type.STRING, description: "List specific grammar/vocab fixes." },
          improvedVersion: { type: Type.STRING },
        },
      },
    },
  });
  return JSON.parse(response.text || "{}");
};

// --- SPEAKING (IELTS) ---
export const generateSpeakingChallenge = async (): Promise<SpeakingChallenge> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Generate an IELTS Speaking Part 1 question suitable for a child (Grade 5).
    Topics: Hobbies, School, Family, Food, Friends.
    Include a brief tip on how to answer.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          part: { type: Type.STRING, enum: ["Part 1", "Part 2"] },
          question: { type: Type.STRING },
          tips: { type: Type.STRING },
        },
      },
    },
  });
  return JSON.parse(response.text || "{}");
};

export const evaluateSpeech = async (audioBase64: string, question: string): Promise<SpeakingResult> => {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
            {
                inlineData: {
                    mimeType: "audio/webm",
                    data: audioBase64
                }
            },
            {
                text: `The user (Grade 5 student) is answering the IELTS Speaking question: "${question}".
                Transcribe their answer.
                Rate their Fluency and Pronunciation (0-9 Band scale equivalent).
                Give encouraging feedback.`
            }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            transcribedText: { type: Type.STRING },
            feedback: { type: Type.STRING },
          },
        },
      },
    });
  
    return JSON.parse(response.text || "{}");
};

// --- SPEAKING (PRONUNCIATION PRACTICE) ---
export const generatePronunciationChallenge = async (topic: string): Promise<PronunciationChallenge> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Generate a sentence for pronunciation practice related to "${topic}".
    It should be suitable for a language learner (Grade 5).
    Provide the phrase, difficulty level (Easy/Medium/Hard), and a brief context.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          phrase: { type: Type.STRING },
          difficulty: { type: Type.STRING },
          context: { type: Type.STRING },
        },
      },
    },
  });
  return JSON.parse(response.text || "{}");
};

// --- VOCABULARY ---
export const generateVocabulary = async (topic: string): Promise<VocabCard[]> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Generate 5 advanced vocabulary words suitable for a 6th grader related to the topic: "${topic}".
    For each word, provide a definition, a sentence using the word, and an emoji.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            word: { type: Type.STRING },
            definition: { type: Type.STRING },
            sentence: { type: Type.STRING },
            emoji: { type: Type.STRING },
          },
        },
      },
    },
  });
  return JSON.parse(response.text || "[]");
};

// --- MAGIC CAMERA ---
export const identifyObjectInImage = async (base64Image: string): Promise<CameraResult> => {
  const base64Data = base64Image.split(',')[1] || base64Image;
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Data,
          },
        },
        {
          text: "Identify the main object in this image for a child. Provide the name, an emoji, and a fun fact.",
        },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          objectName: { type: Type.STRING },
          emoji: { type: Type.STRING },
          funFact: { type: Type.STRING },
        },
      },
    },
  });
  return JSON.parse(response.text || "{}");
};

// --- STORY TIME ---
export const generateStory = async (topic: string): Promise<StoryData> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Write a short, engaging story for a child about: "${topic}".
    Provide a title, the story content (approx 150 words), and a relevant emoji.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          content: { type: Type.STRING },
          emoji: { type: Type.STRING },
        },
      },
    },
  });
  return JSON.parse(response.text || "{}");
};

// --- QUIZ TIME ---
export const generateQuiz = async (topic: string): Promise<QuizQuestion[]> => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Create a 5-question multiple-choice quiz for a 6th grader about: "${topic}".`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswer: { type: Type.STRING },
          },
        },
      },
    },
  });
  return JSON.parse(response.text || "[]");
};

// --- AUDIO HELPERS ---
export const speakText = async (text: string) => {
  try {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') await ctx.resume();

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Puck' }, // Puck is friendly/clear
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      const audioBytes = decodeBase64(base64Audio);
      const audioBuffer = await decodeAudioData(audioBytes, ctx, 24000, 1);
      playAudioBuffer(ctx, audioBuffer);
    }
  } catch (error) {
    console.error("Error generating speech:", error);
  }
};
