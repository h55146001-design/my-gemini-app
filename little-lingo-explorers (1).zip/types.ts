export enum AppView {
  LISTENING = 'LISTENING',
  READING = 'READING',
  WRITING = 'WRITING',
  SPEAKING = 'SPEAKING',
}

export interface ReadingMaterial {
  title: string;
  passage: string;
  vocabulary: { word: string; definition: string }[];
  questions: {
    question: string;
    options: string[];
    correctAnswer: string;
  }[];
}

export interface ListeningExercise {
  script: string; // The text to be spoken by TTS (hidden from user)
  questions: {
    question: string;
    options: string[];
    correctAnswer: string;
  }[];
}

export interface WritingPrompt {
  topic: string;
  question: string;
  minWords: number;
}

export interface WritingFeedback {
  score: number; // Estimated Band score (scaled for kids)
  corrections: string;
  improvedVersion: string;
  comments: string;
}

export interface SpeakingChallenge {
  part: 'Part 1' | 'Part 2';
  question: string;
  tips: string;
}

export interface SpeakingResult {
  score: number;
  transcribedText: string;
  feedback: string;
}

// Added types for other components
export interface VocabCard {
  word: string;
  definition: string;
  sentence: string;
  emoji: string;
}

export interface CameraResult {
  objectName: string;
  emoji: string;
  funFact: string;
}

export interface StoryData {
  title: string;
  content: string;
  emoji: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
}

export interface PronunciationChallenge {
  phrase: string;
  difficulty: string;
  context: string;
}
